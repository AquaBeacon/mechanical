# 紐接続版：X1 Carbon印刷セット

浮き2個と紐は購入品です。円柱浮体・固定ロッドはこのセットに含みません。

|部品|数量|外形 mm|
|---|---:|---|
|dji_osmo_action6_mount|1|104 x 79.45 x 84.5|
|parent_deck|1|216 x 236 x 60|
|parent_rope_keel_adapter|1|60 x 60 x 48|
|parent_spar_ballast_body|1|120 x 120 x 51|
|parent_spar_ballast_lid|1|120 x 120 x 6|
|parent_spar_beam_lower|1|180 x 32 x 32|
|parent_spar_beam_upper|1|107 x 32 x 32|
|parent_spar_camera_bridge|1|140 x 78 x 180|
|parent_spar_coupler_half|2|54 x 64 x 26.75|
|parent_spar_disk|1|225 x 225 x 5|
|parent_spar_fin|4|65 x 125 x 4|
|parent_spar_gps_bridge|1|183 x 96 x 100|
|parent_spar_hub|2|88 x 88 x 32|

数量分のスライサー見積もり：約2.51 kg、約78.3時間（サポート・ブリム込み）。完成品重量ではありません。

PETG / 0.4 mm / 0.20 mm / 壁6周 / 上下6層 / Gyroid 40% / 外側ブリム5 mm / 自動通常サポート / Textured PEI。各部品のXY中心を(138,128)へ配置。既存X1 Carbon禁止領域を維持。浮力・強度と浮き実寸は実機確認が必要。