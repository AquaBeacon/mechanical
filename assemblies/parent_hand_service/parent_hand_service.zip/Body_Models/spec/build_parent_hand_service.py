"""FreeCAD Python: explicit closed/service poses, captive lift carrier and hand sweeps.
Sources are existing downloaded Sony STEP and KiCad PCB; never simplify their solids.
"""
import FreeCAD as A, Part, MeshPart, Import
from pathlib import Path
import json, re, math, copy
R=Path(__file__).resolve().parents[1]
O=R/'assemblies/parent_hand_service'; O.mkdir(exist_ok=True)
P=R/'parts/parent/interior/printed/parent_hand_service'; P.mkdir(exist_ok=True)
def v(*p): return A.Vector(*p)
class CSG:
 def __init__(self,s,t): self.s,self.t=s,t
 def fuse(self,b): return CSG(self.s.fuse(b.s),'union(){'+self.t+b.t+'}')
 def cut(self,b): return CSG(self.s.cut(b.s),'difference(){'+self.t+b.t+'}')
def box(x,y,z,w,d,h): return CSG(Part.makeBox(w,d,h,v(x,y,z)),f'translate([{x},{y},{z}]) cube([{w},{d},{h}]);')
def cyl(x,y,z,r,h): return CSG(Part.makeCylinder(r,h,v(x,y,z)),f'translate([{x},{y},{z}]) cylinder(r={r},h={h},$fn=64);')
def bore(x,y,z,d,h):
 r=d/2/math.cos(math.pi/12); ps=[v(x+r*math.cos(i*math.pi/6),y+r*math.sin(i*math.pi/6),z) for i in range(12)]
 return CSG(Part.Face(Part.makePolygon(ps+[ps[0]])).extrude(v(0,0,h)),f'translate([{x},{y},{z}]) cylinder(r={r},h={h},$fn=12);')
def save(name,c):
 s=c.s.removeSplitter(); assert s.isValid(),name
 s.exportStep(str(P/(name+'.step')))
 MeshPart.meshFromShape(Shape=s,LinearDeflection=.1,AngularDeflection=.2,Relative=False).write(str(P/(name+'.stl')))
 (P/(name+'.scad')).write_text('// Generated from the same CSG operations as STEP. Rebuild with spec/build_parent_hand_service.py.\n'+c.t,encoding='utf-8')
 return s
def holes(board):
 text=(R.parent/'Kicad_project/pcb'/board/(board+'.kicad_pcb')).read_text(encoding='utf-8'); out=[]
 starts=[m.start() for m in re.finditer(r'\(footprint ',text)]
 for a,b in zip(starts,starts[1:]+[len(text)]):
  t=text[a:b]
  if re.search(r'\(property "Reference" "H[1-4]"',t):
   at=re.search(r'\(at ([\d.-]+) ([\d.-]+)',t); out.append([float(at[1]),float(at[2])])
 assert len(out)==4;return out
mh=[[18+x,168-y] for x,y in holes('PARENT_MAIN')]
ph=[[30+y,118+x] for x,y in holes('PARENT_PWR')]
th=[[148+y,144.5+x] for x,y in holes('TX_improved')]
sh=[[149+x,70+y] for x,y in [[2.54,54.61],[50.8,53.34],[7.62,2.54],[35.56,2.54]]]
guides=[[11.5,140],[11.5,190],[137,140],[137,190]]
prop_centres=[[11.5,88],[132,88],[21,187],[127.5,190],[142,110]]
# Floor plate and independent battery supports, all referenced to the existing box.
floor=box(13.5,13.5,13.84,183,203,4.96)
for pts,top in [(ph,28.25),(th,24.75)]:
 for x,y in pts: floor=floor.fuse(cyl(x,y,18.8,3.5,top-18.8)).cut(bore(x,y,13.7,2.6,top-13.7+.1))
for x,y in [[20,64],[123,64],[20,119.5],[123,119.5]]:
 floor=floor.fuse(cyl(x,y,18.8,4,1.2)).cut(bore(x,y,13.7,2.6,6.4))
for x,y in [[25,25],[185,25],[25,205],[185,205]]: floor=floor.cut(bore(x,y,13.7,4.5,5.2))
for x,y in guides:
 floor=floor.fuse(box(x-5,y-13,13.84,10,26,4.96))
 floor=floor.cut(box(x-3.3,y-3.3,13.7,6.6,6.6,5.2))
 # Guide feet attach with two M3 screws along Y; outside board footprints.
 for dy in [-10,10]: floor=floor.cut(bore(x,y+dy,13.7,2.6,5.2))
for x in [35,90]:
 for y in [22,50]:floor=floor.cut(box(x-3,y-1.5,13.7,6,3,5.3))
for x,y in prop_centres:
 floor=floor.fuse(box(x-4,y-13,13.84,8,26,4.96))
 for dy in [-9,9]:
  floor=floor.fuse(cyl(x,y+dy,10.5,4,3.34)).cut(bore(x,y+dy,10.4,3.45,8.5))
  nr=5.8/math.cos(math.pi/6)/2
  ps=[v(x+nr*math.cos(j*math.pi/3),y+dy+nr*math.sin(j*math.pi/3),10.84) for j in range(6)]
  pocket=CSG(Part.Face(Part.makePolygon(ps+[ps[0]])).extrude(v(0,0,2.6)),f'translate([{x},{y+dy},10.84]) cylinder(r={nr},h=2.6,$fn=6);')
  floor=floor.cut(pocket).cut(box(x-2.9,y+dy,10.84,5.8,4.1,2.6)).cut(cyl(x,y+dy,13.34,3.55,.51))
save('floor_plate',floor)
# Compact battery retainer variant; reuse six compliant pads and lid CAD unchanged.
src=R/'parts/parent/interior/printed/parent_lipo_retainer'
bc=json.loads((src/'dimensions.json').read_text()); cap=29
base=box(-4,5,0,111,45,29)
for x in [0,103]:base=base.fuse(box(x-4,-4.5,0,8,64.5,12))
for x,y in bc['bolt_xy']:base=base.fuse(cyl(x,y,0,4,29))
base=base.cut(box(-1.5,7.5,3,106,40,29)).cut(box(-4.1,19.5,5,2.7,16,22))
for x,y in [[0,0],[103,0],[0,55.5],[103,55.5]]:base=base.cut(bore(x,y,-.1,3.45,3.2)).cut(cyl(x,y,3,3.1,30))
for x,y in bc['bolt_xy']:
 base=base.cut(bore(x,y,-.1,3.45,29.2))
 r=5.8/math.cos(math.pi/6)/2;ps=[v(x+r*math.cos(i*math.pi/3),y+r*math.sin(i*math.pi/3),21.5) for i in range(6)]
 nut=CSG(Part.Face(Part.makePolygon(ps+[ps[0]])).extrude(v(0,0,2.5)),f'translate([{x},{y},21.5]) cylinder(r={r},h=2.5,$fn=6);')
 base=base.cut(nut).cut(box(x-r,y-4.5 if y==5 else y,21.5,2*r,4.5,2.5))
save('battery_base',base)
# Carrier leaves port-side edges open for thumb and plug access.
deck=box(13.5,55,54.5,190,135,4.3)
for args in [(13.4,54.9,54.4,118,28.1,4.5),(120,54.9,54.4,84,14.1,4.5),(140.5,146,54.4,63.5,44.1,4.5)]:deck=deck.cut(box(*args))
for pts,top,d in [(mh,63.95,2.6),(sh,63,2.1)]:
 for x,y in pts:deck=deck.fuse(cyl(x,y,58,3 if pts==sh else 3.5,top-58)).cut(bore(x,y,54.9,d,top-54.9+.1))
# Additional insulating bearing surfaces near MAIN USB/SD. These positions were
# checked against the actual KiCad component solids, including underside pins.
# Nominal 0.05 mm copper clearance; fit insulating shims after board measurement.
# Contact-only pads resist downward load; they do NOT certify upward/axial loads.
for x in [34,43,55,70]:deck=deck.fuse(box(x-2,82.5,58,4,4,5.95))
# Longitudinal edge ribs stay clear of all underside component solids. The
# transverse rib at Y92 was rejected because it intersected the Pico pins.
for x in [18,128]:deck=deck.fuse(box(x,84,58,2,84,5.7))
# Stiff bed below MAIN with conservative open pockets for every underside
# component. The original downloaded/exported PCB solid is unchanged.
pcb=Part.read(str(R/'parts/parent/interior/pcb/parent_main/parent_main.step'))
pcb.translate(v(18,168,64))
bed=box(18,83,58.8,112,85,4.9)
for s in pcb.Solids:
 b=s.BoundBox
 if b.ZMin<63.9 and b.intersect(bed.s.BoundBox):
  bed=bed.cut(box(b.XMin-.4,b.YMin-.4,58.7,b.XLength+.8,b.YLength+.8,5.2))
deck=deck.fuse(bed)
# Under-deck ribs use the clear corridors beside the battery and above TX.
for args in [(13.5,83,41.5,2,94,13),(128,83,41.5,3,94,13),(128,69,41.5,75.5,77,13)]:deck=deck.fuse(box(*args))
# C-guide slot admits a narrow carrier tongue while keeping each 6 mm slider captive.
for x,y in guides:
 deck=deck.cut(box(x-5.3,y-5.3,41.4,10.6,10.6,17.5))
 direction=1 if x<20 else -1
 deck=deck.fuse(box(x-3,y-3,10,6,6,48))
 deck=deck.fuse(box(x if direction==1 else x-6,y-1.5,55,6,3,3))
 # The 2 mm cross pin is a separate metal part. Bore through Y.
 hole=Part.makeCylinder(1.1,6.2,v(x,y-3.1,22),v(0,1,0))
 deck=deck.cut(CSG(hole,f'translate([{x},{y-3.1},22]) rotate([-90,0,0]) cylinder(r=1.1,h=6.2,$fn=32);'))
for x in [35,95]:
 handle=box(x,177,57.9,30,6,20.1).cut(box(x+3,176.9,62,24,6.2,12))
 deck=deck.fuse(handle)
# Positive top fastening to service supports, including two near the MAIN ports.
for x,y in prop_centres:
 deck=deck.cut(box(x-4.1,y-13.1,41.4,8.2,26.2,13.1))
 deck=deck.fuse(box(x-4,y-13,54.5,8,26,4.3))
 for dy in [-9,9]:
  deck=deck.cut(bore(x,y+dy,54.4,3.45,4.5))
save('lift_carrier',deck)
guideparts=[]
for i,(x,y) in enumerate(guides):
 direction=1 if x<20 else -1
 g=box(x-5,y-5,18.8,10,10,66.7).fuse(box(x-5,y-13,18.8,10,26,3))
 g=g.cut(box(x-3.3,y-3.3,18.7,6.6,6.6,66.9))
 g=g.cut(box(x if direction==1 else x-5.1,y-1.8,18.7,5.1,3.6,67))
 # End-stopped travel slot on both Y faces, pin centre Z22..83.
 g=g.cut(box(x-1.2,y-5.1,22,2.4,10.2,61))
 for z in [22,83]:
  hole=Part.makeCylinder(1.2,10.2,v(x,y-5.1,z),v(0,1,0))
  g=g.cut(CSG(hole,f'translate([{x},{y-5.1},{z}]) rotate([-90,0,0]) cylinder(r=1.2,h=10.2,$fn=32);'))
 for dy in [-10,10]:g=g.cut(bore(x,y+dy,18.7,3.45,3.2))
 guideparts.append(save('guide_'+str(i),g))
old=json.loads((R/'assemblies/parent_service_review/placement.json').read_text(encoding='utf-8'))
a=copy.deepcopy(old);a['name']='parent_hand_service';a['items']=[it for it in a['items'] if not it['label'].startswith('main_spacer')]
def setops(label,xyz,rot=None):
 it=next(it for it in a['items'] if it['label']==label);it['ops']=[{'translate':xyz}]+([{'rotate':rot}] if rot else []);it.pop('note',None)
setops('p_main',[18,168,64]);setops('p_pwr',[30,118,28.3],[0,0,90]);setops('tx_improved',[148,144.5,24.8],[0,0,90]);setops('spresense',[149,70,63])
setops('lipo',[122.5,108.5,23],[0,0,180]);setops('lipo_tray',[20,64,20]);setops('lipo_ret_lid',[20,64,49]);setops('lipo_ret_pads',[20,64,20])
for i,(x,y) in enumerate(bc['bolt_xy']):
 setops('lipo_ret_bolt_'+str(i),[20+x,64+y,52]);setops('lipo_ret_nut_'+str(i),[20+x,64+y,41.6])
for i,(x,y) in enumerate([[0,0],[103,0],[0,55.5],[103,55.5]]):setops('lipo_ret_mount_'+str(i),[20+x,64+y,23])
for label,name in [('plate','floor_plate'),('lipo_tray','battery_base')]:
 it=next(it for it in a['items'] if it['label']==label);it['part']=str(P.relative_to(R)).replace('\\','/');it['file']=name
 if label=='plate':it['ops']=[]
def add(label,name,color): a['items'].append(dict(label=label,part=str(P.relative_to(R)).replace('\\','/'),file=name,group='interior',color=color,ops=[]))
add('lift_carrier','lift_carrier','Orange')
for i in range(4):add('guide_'+str(i),'guide_'+str(i),'Gray')
save('lid_keepout',box(0,0,90.64,210,230,9.66))
add('lid_keepout','lid_keepout','LightGray')
a['items'][-1]['alpha']=.18
a['items'][-1]['note']='Non-printable conservative lid exclusion volume; underside datum90.64 from existing box drawing model. Not detailed vendor lid CAD.'
moving=['p_main','spresense','lift_carrier']
def screw(label,stem,x,y,z,moves=False):
 a['items'].append(dict(label=label,part='parts/common/interior/cots/screw',file=stem,group='interior',color='Silver',ops=[{'translate':[x,y,z]}]))
 if moves:moving.append(label)
for i,(x,y) in enumerate(guides):
 for j,dy in enumerate([-10,10]):screw(f'guide_mount_{i}_{j}','screw_m3x8',x,y+dy,21.8)
for i,(x,y) in enumerate(mh):screw('main_mount_'+str(i),'screw_m3x8',x,y,65.6,True)
for i,(x,y) in enumerate(sh):screw('sony_mount_'+str(i),'screw_m2_5x6',x,y,64.6,True)
for i,(x,y) in enumerate(ph):screw('pwr_mount_'+str(i),'screw_m3x8',x,y,29.9)
for i,(x,y) in enumerate(th):screw('tx_mount_'+str(i),'screw_m3x8',x,y,26.4)
# Metal stop pins with retaining heads are explicit geometry; pin threads are not simulated.
for i,(x,y) in enumerate(guides):
 pin=Part.makeCylinder(1,13,v(x,y-6.5,22),v(0,1,0)).fuse(Part.makeCylinder(2,1,v(x,y-7.5,22),v(0,1,0))).fuse(Part.makeCylinder(2,1,v(x,y+6.5,22),v(0,1,0)))
 save('stop_pin_'+str(i),CSG(pin,f'translate([{x},{y-7.5},22]) rotate([-90,0,0]) union(){{cylinder(r=2,h=1);translate([0,0,1]) cylinder(r=1,h=13);translate([0,0,14]) cylinder(r=2,h=1);}}'))
 add('stop_pin_'+str(i),'stop_pin_'+str(i),'Silver');moving.append('stop_pin_'+str(i))
# Service position is positively supported by removable 61 mm props, not held by the hands.
for i,(sx,y) in enumerate(prop_centres):
 # Printed compression sleeve; two steel M3 tie fasteners clamp floor,
 # sleeve and carrier together. No repeated self-tapping structural joints.
 fx=sx-4
 prop=box(fx,y-13,18.8,8,26,96.7)
 for dy in [-9,9]:prop=prop.cut(bore(sx,y+dy,18.7,3.45,96.9))
 save('service_prop_'+str(i),prop)
 # Closed storage is outside this fixture; deliberate service-only installation.
 a.setdefault('service_only',[]).append(dict(label='service_prop_'+str(i),part=str(P.relative_to(R)).replace('\\','/'),file='service_prop_'+str(i),group='interior',color='Yellow',ops=[]))
 # The removed service prop also has an explicit restrained storage pose inside the box.
 bb=Part.read(str(P/('service_prop_'+str(i)+'.step'))).BoundBox
 sz=18.8+8*i
 angle=90 if i<2 else -90
 xyz=[18-bb.ZMin,23-bb.YMin,sz+bb.XMax] if angle==90 else [18+bb.ZMax,23-bb.YMin,sz-bb.XMin]
 a['items'].append(dict(label='stored_prop_'+str(i),part=str(P.relative_to(R)).replace('\\','/'),file='service_prop_'+str(i),group='interior',color='Yellow',ops=[{'translate':xyz},{'rotate':[0,angle,0]}]))
 for j,dy in enumerate([-9,9]):
  stem=f'tie_rod_{i}_{j}'
  bolt=cyl(sx,y+dy,10.3,1.5,110).fuse(cyl(sx,y+dy,120.3,2.75,3))
  hr=2.5/math.cos(math.pi/6)/2
  ps=[v(sx+hr*math.cos(k*math.pi/3),y+dy+hr*math.sin(k*math.pi/3),121.9) for k in range(6)]
  socket=CSG(Part.Face(Part.makePolygon(ps+[ps[0]])).extrude(v(0,0,1.5)),f'translate([{sx},{y+dy},121.9]) cylinder(r={hr},h=1.5,$fn=6);')
  save(stem,bolt.cut(socket))
  fasteners=[dict(label=stem,part=str(P.relative_to(R)).replace('\\','/'),file=stem,group='interior',color='Silver',ops=[],note='Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.')]
  fasteners.append(dict(label=f'prop_top_washer_{i}_{j}',part='parts/common/interior/cots/screw',file='screw_washer_m3_05',group='interior',color='Silver',ops=[{'translate':[sx,y+dy,119.8]}]))
  for suffix,file,z in [('floor_nut','screw_nut_m3',10.94),('floor_washer','screw_washer_m3_05',13.34)]:
   a['items'].append(dict(label=f'fixed_prop_{suffix}_{i}_{j}',part='parts/common/interior/cots/screw',file=file,group='interior',color='Silver',ops=[{'translate':[sx,y+dy,z]}],note='Captive below fixed floor; install before mounting floor in case. Stays in both poses.'))
  a['service_only']+=fasteners
  for f in fasteners:
   it=copy.deepcopy(f);it['label']='stored_'+f['label'];it['ops']=[{'translate':xyz},{'rotate':[0,angle,0]}]+f['ops'];a['items'].append(it)
for i,x in enumerate([35,90]):
 storage_top=18.8+8*len(prop_centres)
 strap=box(x-2.5,21,storage_top,5,30,2).fuse(box(x-2.5,21,12.8,5,2,storage_top+2-12.8)).fuse(box(x-2.5,49,12.8,5,2,storage_top+2-12.8)).fuse(box(x-2.5,21,12.8,5,30,1))
 save('storage_strap_'+str(i),strap)
 add('stored_strap_'+str(i),'storage_strap_'+str(i),'Black')
 a['items'][-1]['note']='Flexible adjustable retaining strap; non-printable simplified routing envelope.'
shapes={}
def transform(s,ops):
 for op in reversed(ops):
  if 'rotate' in op:
   for axis,ang in zip([v(1,0,0),v(0,1,0),v(0,0,1)],op['rotate']):s.rotate(v(0,0,0),axis,ang)
  if 'translate' in op:s.translate(v(*op['translate']))
 return s
for it in a['items']:
 if it['part']=='parts/common/interior/cots/screw' and it['file']=='nut_m3':it['file']='screw_nut_m3'
 shapes[it['label']]=transform(Part.read(str(R/it['part']/(it.get('file',Path(it['part']).name)+'.step'))),it['ops'])
service={k:(s.translated(v(0,0,61)) if k in moving else s.copy()) for k,s in shapes.items() if k!='lid_keepout' and not k.startswith('stored_')}
for it in a['service_only']:
 if it['part']=='parts/common/interior/cots/screw' and it['file']=='nut_m3':it['file']='screw_nut_m3'
 service[it['label']]=transform(Part.read(str(R/it['part']/(it['file']+'.step'))),it['ops'])
def asmexport(name,ss):
 doc=A.newDocument(name)
 for k,s in ss.items():ob=doc.addObject('PartDesign::Feature',k);ob.Label=k;ob.Shape=s
 Import.export(doc.Objects,str(O/(name+'.step')));A.closeDocument(doc.Name)
asmexport('closed',shapes);asmexport('service',service)
a['lift_mm']=61;a['moving_labels']=moving;a['note']='Provisional captive lift design. Service means lid removed and carrier raised 61 mm; boards remain attached.'
a['service_prop_centres_mm']=prop_centres
a['coordinate_system']='Box exterior southwest bottom origin; millimetres. X210 Y230; floor3.84; provisional boss height10; fixed plate bottom13.84 top18.8; closed carrier deck bottom54.5 top58.8; underside ribs to41.5; lift61.'
(O/'placement.json').write_text(json.dumps(a,ensure_ascii=False,indent=2),encoding='utf-8')
b=copy.deepcopy(a);b['name']='service';b['items']+=b.pop('service_only')
b['items']=[it for it in b['items'] if it['label']!='lid_keepout' and not it['label'].startswith('stored_')]
for it in b['items']:
 if it['label'] in moving:it['ops'].insert(0,{'translate':[0,0,61]})
(O/'service_placement.json').write_text(json.dumps(b,ensure_ascii=False,indent=2),encoding='utf-8')
# Real hand grip assumption: 90 wide x75 deep x35 thick; fingertips connect to port mouth.
ports=[('MAIN_USB',39.11,80.73,68.6,-1),('MAIN_SD',62,82.29,66.5,-1),('SONY_MAIN_USB',169.29,68.4,66.1,-1),('SONY_EXT_USB',193.6,70.94,61.5,-1),('SONY_SD',186.18,143.28,65.4,1)]
result=[];volumes={}
for name,x,y,z,d in ports:
 z+=61
 # Palm starts 12 mm from mouth, fingertips stop 3 mm short of socket body.
 palm=Part.makeBox(90,75,35,v(x-45,y+12 if d==1 else y-87,z-17.5))
 fingers=Part.makeBox(20,9,24,v(x-10,y+3 if d==1 else y-12,z-12))
 grip=palm.fuse(fingers)
 approach=palm.fuse(Part.makeBox(90,75,100,v(x-45,y+12 if d==1 else y-87,z-17.5)))
 approach=approach.fuse(Part.makeBox(20,9,89,v(x-10,y+3 if d==1 else y-12,z-12)))
 sweep=grip.fuse(approach)
 col=[]
 for k,s in service.items():
  if s.BoundBox.intersect(sweep.BoundBox):
   vol=s.common(sweep).Volume
   if vol>.1:col.append(dict(part=k,intersection_mm3=round(vol,3)))
 volumes[name]=sweep;result.append(dict(port=name,mouth_mm=[x,y,z],hand_mm=[90,75,35],collisions=col));print(name,col,flush=True)
asmexport('hand_sweeps',volumes)
# Mechanical booleans excluding intended fastener engagement and foam contact.
pairs=[]
elec=['p_main','p_pwr','tx_improved','spresense','lipo']
for i,k in enumerate(elec):
 for other in elec[i+1:]+['plate','box_bcas212310g','pen_tether','pen_td04a','lift_carrier']+[f'guide_{j}' for j in range(4)]:
  vol=shapes[k].common(shapes[other]).Volume if shapes[k].BoundBox.intersect(shapes[other].BoundBox) else 0
  pairs.append(dict(a=k,b=other,intersection_mm3=round(vol,4)))
  if vol>.1:print('COLLISION',pairs[-1],flush=True)
report=dict(status='PASS' if all(not p['collisions'] for p in result) and all(p['intersection_mm3']<.1 for p in pairs) else 'FAIL',ports=result,closed_mechanical_pairs=pairs,hand_assumption_mm=[90,75,35],lift_required_mm=61,not_measured=['IMU connector stack height','box floor boss height','LiPo actual dimensions','human grip validation','guide load and harness flex'],source='Sony official downloaded STEP and KiCad PCB, retained without simplified component solids')
travel=[]
for z in [0,12.2,24.4,36.6,48.8,61]:
 s=shapes['lift_carrier'].translated(v(0,0,z))
 for k in ['plate','lipo_tray','lipo_ret_lid','lipo','box_bcas212310g']+[f'guide_{i}' for i in range(4)]:
  vol=s.common(shapes[k]).Volume if s.BoundBox.intersect(shapes[k].BoundBox) else 0
  if vol>.1:travel.append(dict(lift_mm=z,part=k,intersection_mm3=round(vol,3)))
report['sampled_carrier_travel_collisions']=travel
supports=[]
for i in range(len(prop_centres)):
 s=service['service_prop_'+str(i)]
 supports.append(dict(prop=i,floor_contact_mm=s.distToShape(service['plate'])[0],carrier_contact_mm=s.distToShape(service['lift_carrier'])[0]))
report['service_support_contacts']=supports
report['status']='PASS' if report['status']=='PASS' and not travel and all(max(p['floor_contact_mm'],p['carrier_contact_mm'])<1e-5 for p in supports) else 'FAIL'
pack=shapes['lipo']
battery_contacts={'floor':pack.distToShape(shapes['lipo_tray'])[0]}
for i,s in enumerate(shapes['lipo_ret_pads'].Solids):battery_contacts['foam_'+str(i)]=pack.distToShape(s)[0]
battery_rigid=[]
for k in ['lipo_tray','lipo_ret_lid']+[k for k in shapes if k.startswith('lipo_ret_bolt_') or k.startswith('lipo_ret_mount_')]:
 vol=pack.common(shapes[k]).Volume if pack.BoundBox.intersect(shapes[k].BoundBox) else 0
 battery_rigid.append(dict(part=k,intersection_mm3=round(vol,4)))
report['battery_contact_distances_mm']=battery_contacts
report['battery_rigid_pairs']=battery_rigid
report['battery_nominal_mm']=[102,34,23]
report['status']='PASS' if report['status']=='PASS' and max(battery_contacts.values())<1e-5 and all(p['intersection_mm3']<.1 for p in battery_rigid) else 'FAIL'
fixture_collisions=[]
for k in [f'guide_{i}' for i in range(4)]+[f'service_prop_{i}' for i in range(len(prop_centres))]:
 for other in elec+['lipo_tray','lipo_ret_lid','box_bcas212310g','lift_carrier']:
  s,t=service[k],service[other]
  vol=s.common(t).Volume if s.BoundBox.intersect(t.BoundBox) else 0
  if vol>.1:fixture_collisions.append(dict(a=k,b=other,intersection_mm3=round(vol,3)))
report['service_fixture_collisions']=fixture_collisions
report['status']='PASS' if report['status']=='PASS' and not fixture_collisions else 'FAIL'
hardware_collisions=[]
for k in service:
 if k.startswith(('tie_rod_','prop_','fixed_prop_')):
  for other in elec+['lipo_tray','lipo_ret_lid','box_bcas212310g','pen_tether','pen_td04a']:
   s,t=service[k],service[other]
   vol=s.common(t).Volume if s.BoundBox.intersect(t.BoundBox) else 0
   if vol>.1:hardware_collisions.append(dict(a=k,b=other,intersection_mm3=round(vol,3)))
report['service_hardware_collisions']=hardware_collisions
report['status']='PASS' if report['status']=='PASS' and not hardware_collisions else 'FAIL'
report['status_scope']='CAD hand sweeps, external component/fixture interference, sampled lift motion and nominal battery retention. Does not verify internal Sony mating, harness motion, structural load or human operation.'
report['manufacturing_release']=False
report['rigidity_requirement']=dict(load_N=20,maximum_displacement_mm=.2,reference='case; USB/SD connector displacement including PCB, carrier, guides and service supports',status='NOT_VERIFIED',added_main_support_xy_mm=[[x,84.5] for x in [34,43,55,70]],nominal_pad_gap_mm=.05,limitations=['Contact pads require measured insulating shims','Contact-only supports do not restrain uplift','Sony internal support and connector solder loads not verified','Guide clearance, support bending and joints must be included; geometric PASS is not a rigidity PASS'])
storage_collisions=[]
for k in [k for k in shapes if k.startswith('stored_')]:
 for other in elec+['plate','lipo_tray','lipo_ret_lid','box_bcas212310g','lift_carrier','pen_tether','pen_td04a']:
  s,t=shapes[k],shapes[other]
  vol=s.common(t).Volume if s.BoundBox.intersect(t.BoundBox) else 0
  if vol>.1:storage_collisions.append(dict(a=k,b=other,intersection_mm3=round(vol,3)))
report['closed_storage_collisions']=storage_collisions
report['status']='PASS' if report['status']=='PASS' and not storage_collisions else 'FAIL'
lid_checks=[]
for it in a['items']:
 k=it['label']
 if k in ['lid_keepout','box_bcas212310g','pen_tether','pen_td04a']:continue
 s=shapes[k];margin=90.64-s.BoundBox.ZMax
 vol=s.common(shapes['lid_keepout']).Volume if s.BoundBox.intersect(shapes['lid_keepout'].BoundBox) else 0
 lid_checks.append(dict(part=k,max_z_mm=round(s.BoundBox.ZMax,4),lid_clearance_mm=round(margin,4),intersection_mm3=round(vol,4)))
report['lid_closure']=dict(lid_underside_z_mm=90.64,closed_max_z_mm=max(c['max_z_mm'] for c in lid_checks),minimum_clearance_mm=min(c['lid_clearance_mm'] for c in lid_checks),checks=lid_checks,imu_extra_5mm_clearance_mm=90.64-(63+24),lid_model='Conservative keepout proxy derived from existing enclosure drawing datum, not detailed vendor lid CAD')
report['status']='PASS' if report['status']=='PASS' and all(c['lid_clearance_mm']>=3 and c['intersection_mm3']<.1 for c in lid_checks) else 'FAIL'
(O/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
(O/'hole_sources.json').write_text(json.dumps(dict(MAIN=mh,PWR=ph,TX=th,SONY=sh,derived_from_kicad=True),indent=2))
print('RESULT',report['status'],flush=True)

