from pathlib import Path
import subprocess
R=Path(__file__).resolve().parents[1];O=R/'assemblies/parent_hand_service'
PY='C:/Python313/python.exe';OSC='C:/Program Files/OpenSCAD/openscad.exe'
for pose,src,cam in [('closed','placement.json','360,-290,300,105,115,35'),('service','service_placement.json','360,-290,300,105,115,75')]:
 view=O/(pose+'_view.scad')
 subprocess.run([PY,str(R/'scad/lib/asm_gen.py'),str(O/src),str(view)],check=True)
 subprocess.run([OSC,'-o',str(O/(pose+'.png')),'--imgsize=1400,1100','--projection=o','--viewall','--camera='+cam,str(view)],check=True,capture_output=True,creationflags=0x08000000)
subprocess.run([OSC,'-o',str(O/'hand_access.png'),'-D','lift_mm=61','-D','show_hand_space=true','--imgsize=1400,1100','--projection=o','--viewall','--camera=360,-290,300,105,115,75',str(O/'parent_hand_service.scad')],check=True,capture_output=True,creationflags=0x08000000)
print('Rendered both poses and hand access')
