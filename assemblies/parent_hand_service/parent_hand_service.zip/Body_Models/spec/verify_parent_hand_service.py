"""Run using FreeCAD Python. Render SCAD independently, compare with STEP, verify both exported poses."""
import FreeCAD as A, Part, Mesh
from pathlib import Path
import json, subprocess, os, runpy, io, contextlib, hashlib
R=Path(__file__).resolve().parents[1];O=R/'assemblies/parent_hand_service';P=R/'parts/parent/interior/printed/parent_hand_service'
C=O/'scad_check';C.mkdir(exist_ok=True)
checks=[]
for f in sorted(P.glob('*.scad')):
 if f.stem.startswith(('stop_pin','tie_rod','storage_strap','lid_keepout')):continue
 target=C/(f.stem+'.stl')
 result=subprocess.run(['C:/Program Files/OpenSCAD/openscad.exe','-o',str(target),str(f)],capture_output=True,text=True,creationflags=0x08000000)
 assert result.returncode==0,(f.name,result.stderr)
 s=Part.read(str(f.with_suffix('.step')));m=Mesh.Mesh(str(target))
 delta=max(abs(getattr(s.BoundBox,k)-getattr(m.BoundBox,k)) for k in ['XMin','XMax','YMin','YMax','ZMin','ZMax'])
 vol=abs(s.Volume-m.Volume)/s.Volume
 c=dict(part=f.stem,valid_step=s.isValid(),closed_stl=m.isSolid(),scad_bbox_difference_mm=delta,scad_relative_volume_difference=vol,solid_count=len(s.Solids))
 assert c['valid_step'] and c['closed_stl'] and delta<.05 and vol<.02,c
 checks.append(c);print(f.stem,'PASS',flush=True)
(O/'scad_step_checks.json').write_text(json.dumps(checks,indent=2))
poses=[]
for pose,path in [('closed','placement.json'),('service','service_placement.json')]:
 os.environ.update(ASM_JSON=str(O/path),ASM_ROOT=str(R),STEP_IN=str(O/(pose+'.step')))
 log=io.StringIO()
 try:
  with contextlib.redirect_stdout(log):runpy.run_path(str(R/'scad/lib/verify_asm_step.py'),run_name='__main__')
 except SystemExit as e:
  assert e.code in [None,0],(pose,e.code)
 (O/(pose+'_verify.log')).write_text(log.getvalue(),encoding='utf-8')
 poses.append(dict(pose=pose,items=len(json.loads((O/path).read_text(encoding='utf-8'))['items']),status='PASS',bbox_tolerance_mm=.5,step_sha256=hashlib.sha256((O/(pose+'.step')).read_bytes()).hexdigest()))
 print(pose,'ASSEMBLY PASS',flush=True)
(O/'assembly_checks.json').write_text(json.dumps(poses,indent=2))
print('PASS independent SCAD/STEP and both assembly poses',flush=True)
