include <child_simple_frame.scad>
child_simple_guard();
