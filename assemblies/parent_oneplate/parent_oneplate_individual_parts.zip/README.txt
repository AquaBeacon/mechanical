部品別データ（最新版・カメラ固定穴貫通版）

STL: 印刷向き、底面Z=0。STEP/SCAD: 設計時の組立座標。

parent_oneplate_frame: 1個
parent_oneplate_bar: 2個
parent_oneplate_td_support: 1個
parent_light_jaw: 1個
