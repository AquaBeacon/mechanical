# X1 Carbon 印刷セット：下向きカメラ・TD04A版

STLは印刷向きです。浮き2個・紐・金具・箱・センサーは購入品です。

|部品|数量|印刷寸法 mm|
|---|---:|---|
|parent_spar_beam_lower|1|180 × 32 × 32|
|parent_spar_beam_upper|1|107 × 32 × 32|
|parent_spar_coupler_half|2|54 × 64 × 26.75|
|parent_spar_ballast_body|1|120 × 120 × 51|
|parent_spar_ballast_lid|1|120 × 120 × 6|
|parent_spar_gps_bridge|1|183 × 96 × 100|
|parent_deck|1|216 × 236 × 60|
|parent_rope_keel_adapter|1|60 × 60 × 48|
|parent_fin_cartridge|1|225 × 225 × 130|
|parent_sensor_carrier|1|210 × 141 × 55|
|parent_td04a_clamp_body|1|64 × 60 × 27|
|parent_td04a_clamp_cap|1|58 × 32 × 19|
|dji_osmo_action6_mount|1|104 × 79.45 × 84.5|

13種類14点。スライサー見積もり：約2.34 kg、約72.4時間（サポート・ブリム込み）。完成品重量ではありません。

PETG / 0.4 mm / 0.20 mm / 壁6周 / 上下6層 / Gyroid 40% / 外側ブリム5 mm / 自動通常サポート / Textured PEI。XY中心を(138,128)へ配置し、X1 Carbonの禁止領域を維持。

TD04Aは胴径26・胴長55の仮寸法。実物でクランプ適合を確認してから本印刷してください。カメラケース・浮きも実測未確定。組立方法と検証の範囲はASSEMBLY.mdを参照。