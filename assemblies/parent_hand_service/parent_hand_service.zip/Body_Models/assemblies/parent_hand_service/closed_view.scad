// =====================================================================
// parent_hand_service_view.scad
// !! 自動生成ファイル - 編集しないこと。placement.json を直して
//    build.ps1 -Assemblies で再生成する。
// Provisional captive lift design. Service means lid removed and carrier raised 61 mm; boards remain attached.
// 座標系: Box exterior southwest bottom origin; millimetres. X210 Y230; floor3.84; provisional boss height10; fixed plate bottom13.84 top18.8; closed carrier deck bottom54.5 top58.8; underside ribs to41.5; lift61.
// =====================================================================

show_vessel = true;
show_interior = true;

if (show_interior) color("SteelBlue", 1) translate([18, 168, 64])  import("../../parts/parent/interior/pcb/parent_main/parent_main.stl");
if (show_interior) color("MediumSeaGreen", 1) translate([30, 118, 28.3]) rotate([0, 0, 90])  import("../../parts/parent/interior/pcb/parent_pwr/parent_pwr.stl");
if (show_interior) color("Gold", 1) translate([148, 144.5, 24.8]) rotate([0, 0, 90])  import("../../parts/parent/interior/pcb/tx_improved/tx_improved.stl");
if (show_interior) color("SandyBrown", 1) translate([149, 70, 63])  import("../../parts/parent/interior/cots/spresense_service_stack/spresense_service_stack.stl");
if (show_interior) color("IndianRed", 1) translate([122.5, 108.5, 23]) rotate([0, 0, 180])  import("../../parts/common/interior/cots/lipo_3s_2200_zeee/lipo_3s_2200_zeee_pack.stl");
// 2026-09-26 service placement; WetLink Penetrator M10 (参考モデル・仮寸)。南壁 (Y=0) x=120, 軸 z=65。C1 テザー → P-MAIN J_TETH1 (箱 x≈123 の直下)。頭+プラグは箱外 y=-22..0、ねじ+ナットが箱内 y=0..14.5 (モデル壁 6.1 基準。実壁 3.08 なら 11.5)。容器内に出るのは素の導体 (外被は濡れ側で終端)。型番 -045..-085 はテザー外径待ち
if (show_vessel) color("Silver", 1) translate([120, 0, 65]) rotate([-90, 0, 0])  import("../../parts/common/exterior/cots/wetlink_penetrator_m10/wetlink_penetrator_m10_ref_bcas.stl");
// 2026-09-26 service placement; WetLink Penetrator M10 (参考モデル・仮寸)。南壁 (Y=0) x=85, 軸 z=65。C3 TD04A → TX (右列)。3P プラグは通らないのでケーブルを切って容器内で端子台に落とす前提 (td04a_transducer.md)。テザー側とのピッチ 35 = 16mm トルクレンチの振り代。東へ寄せられないのは SPRESENSE (箱 X 134.5-188) の天面が仮値 30 で、その上を通すと隙間 0.3 になるため (spec/parent_interior_layout.py check_penetrators)
if (show_vessel) color("Silver", 1) translate([85, 0, 65]) rotate([-90, 0, 0])  import("../../parts/common/exterior/cots/wetlink_penetrator_m10/wetlink_penetrator_m10_ref_bcas.stl");
if (show_interior) color("Orange") translate([20, 64, 49])  import("../../parts/parent/interior/printed/parent_lipo_retainer/parent_lipo_retainer_lid.stl");
if (show_interior) color("LightPink") translate([20, 64, 20])  import("../../parts/parent/interior/printed/parent_lipo_retainer/parent_lipo_retainer_pads.stl");
if (show_interior) color("Silver") translate([32, 69, 52])  import("../../parts/common/interior/cots/screw/screw_m3x12.stl");
if (show_interior) color("Silver") translate([32, 69, 41.6])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
if (show_interior) color("Silver") translate([111, 69, 52])  import("../../parts/common/interior/cots/screw/screw_m3x12.stl");
if (show_interior) color("Silver") translate([111, 69, 41.6])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
if (show_interior) color("Silver") translate([32, 114, 52])  import("../../parts/common/interior/cots/screw/screw_m3x12.stl");
if (show_interior) color("Silver") translate([32, 114, 41.6])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
if (show_interior) color("Silver") translate([111, 114, 52])  import("../../parts/common/interior/cots/screw/screw_m3x12.stl");
if (show_interior) color("Silver") translate([111, 114, 41.6])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
if (show_interior) color("Silver") translate([20, 64, 23])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([123, 64, 23])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([20, 119.5, 23])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([123, 119.5, 23])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Orange")  import("../../parts/parent/interior/printed/parent_hand_service/lift_carrier.stl");
if (show_interior) color("Gray")  import("../../parts/parent/interior/printed/parent_hand_service/guide_0.stl");
if (show_interior) color("Gray")  import("../../parts/parent/interior/printed/parent_hand_service/guide_1.stl");
if (show_interior) color("Gray")  import("../../parts/parent/interior/printed/parent_hand_service/guide_2.stl");
if (show_interior) color("Gray")  import("../../parts/parent/interior/printed/parent_hand_service/guide_3.stl");
if (show_interior) color("Silver") translate([11.5, 130, 21.8])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([11.5, 150, 21.8])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([11.5, 180, 21.8])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([11.5, 200, 21.8])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([137, 130, 21.8])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([137, 150, 21.8])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([137, 180, 21.8])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([137, 200, 21.8])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([22.5, 163.5, 65.6])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([22.5, 88, 65.6])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([125.5, 88, 65.6])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([125.5, 163.5, 65.6])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([151.54, 124.61, 64.6])  import("../../parts/common/interior/cots/screw/screw_m2_5x6.stl");
if (show_interior) color("Silver") translate([199.8, 123.34, 64.6])  import("../../parts/common/interior/cots/screw/screw_m2_5x6.stl");
if (show_interior) color("Silver") translate([156.62, 72.54, 64.6])  import("../../parts/common/interior/cots/screw/screw_m2_5x6.stl");
if (show_interior) color("Silver") translate([184.56, 72.54, 64.6])  import("../../parts/common/interior/cots/screw/screw_m2_5x6.stl");
if (show_interior) color("Silver") translate([35, 123, 29.9])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([109, 213, 29.9])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([35, 213, 29.9])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([109, 123, 29.9])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([194, 210.5, 26.4])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([194, 144.5, 26.4])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([152, 210.5, 26.4])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver") translate([152, 144.5, 26.4])  import("../../parts/common/interior/cots/screw/screw_m3x8.stl");
if (show_interior) color("Silver")  import("../../parts/parent/interior/printed/parent_hand_service/stop_pin_0.stl");
if (show_interior) color("Silver")  import("../../parts/parent/interior/printed/parent_hand_service/stop_pin_1.stl");
if (show_interior) color("Silver")  import("../../parts/parent/interior/printed/parent_hand_service/stop_pin_2.stl");
if (show_interior) color("Silver")  import("../../parts/parent/interior/printed/parent_hand_service/stop_pin_3.stl");
if (show_interior) color("Yellow") translate([-0.8, -52, 34.3]) rotate([0, 90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_0.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([11.5, 79, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([11.5, 79, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([-0.8, -52, 34.3]) rotate([0, 90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_0_0.stl");
if (show_interior) color("Silver") translate([-0.8, -52, 34.3]) rotate([0, 90, 0]) translate([11.5, 79, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([11.5, 97, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([11.5, 97, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([-0.8, -52, 34.3]) rotate([0, 90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_0_1.stl");
if (show_interior) color("Silver") translate([-0.8, -52, 34.3]) rotate([0, 90, 0]) translate([11.5, 97, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
if (show_interior) color("Yellow") translate([-0.8, -52, 162.8]) rotate([0, 90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_1.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([132, 79, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([132, 79, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([-0.8, -52, 162.8]) rotate([0, 90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_1_0.stl");
if (show_interior) color("Silver") translate([-0.8, -52, 162.8]) rotate([0, 90, 0]) translate([132, 79, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([132, 97, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([132, 97, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([-0.8, -52, 162.8]) rotate([0, 90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_1_1.stl");
if (show_interior) color("Silver") translate([-0.8, -52, 162.8]) rotate([0, 90, 0]) translate([132, 97, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
if (show_interior) color("Yellow") translate([133.5, -151, 17.8]) rotate([0, -90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_2.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([21, 178, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([21, 178, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([133.5, -151, 17.8]) rotate([0, -90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_2_0.stl");
if (show_interior) color("Silver") translate([133.5, -151, 17.8]) rotate([0, -90, 0]) translate([21, 178, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([21, 196, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([21, 196, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([133.5, -151, 17.8]) rotate([0, -90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_2_1.stl");
if (show_interior) color("Silver") translate([133.5, -151, 17.8]) rotate([0, -90, 0]) translate([21, 196, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
if (show_interior) color("Yellow") translate([133.5, -154, -80.7]) rotate([0, -90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([127.5, 181, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([127.5, 181, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([133.5, -154, -80.7]) rotate([0, -90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_3_0.stl");
if (show_interior) color("Silver") translate([133.5, -154, -80.7]) rotate([0, -90, 0]) translate([127.5, 181, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([127.5, 199, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([127.5, 199, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([133.5, -154, -80.7]) rotate([0, -90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_3_1.stl");
if (show_interior) color("Silver") translate([133.5, -154, -80.7]) rotate([0, -90, 0]) translate([127.5, 199, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
if (show_interior) color("Yellow") translate([133.5, -74, -87.2]) rotate([0, -90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_4.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([142, 101, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([142, 101, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([133.5, -74, -87.2]) rotate([0, -90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_4_0.stl");
if (show_interior) color("Silver") translate([133.5, -74, -87.2]) rotate([0, -90, 0]) translate([142, 101, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([142, 119, 10.94])  import("../../parts/common/interior/cots/screw/screw_nut_m3.stl");
// Captive below fixed floor; install before mounting floor in case. Stays in both poses.
if (show_interior) color("Silver") translate([142, 119, 13.34])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Purchased M3x110 socket-head screw, D5.5 H3 AF2.5, based on manufacturer dimensions; NOT printed. Threads omitted.
if (show_interior) color("Silver") translate([133.5, -74, -87.2]) rotate([0, -90, 0])  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_4_1.stl");
if (show_interior) color("Silver") translate([133.5, -74, -87.2]) rotate([0, -90, 0]) translate([142, 119, 119.8])  import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl");
// Flexible adjustable retaining strap; non-printable simplified routing envelope.
if (show_interior) color("Black")  import("../../parts/parent/interior/printed/parent_hand_service/storage_strap_0.stl");
// Flexible adjustable retaining strap; non-printable simplified routing envelope.
if (show_interior) color("Black")  import("../../parts/parent/interior/printed/parent_hand_service/storage_strap_1.stl");
// 2026-09-26 service placement; 183x203 t5。プレート左下 = 箱 (13.5,13.5)、下面 z=13.8 (床3.8+ボス10 仮)
if (show_interior) color("Orange", 0.9)  import("../../parts/parent/interior/printed/parent_hand_service/floor_plate.stl");
if (show_interior) color("DarkOrange", 0.9) translate([20, 64, 20])  import("../../parts/parent/interior/printed/parent_hand_service/battery_base.stl");
// タカチ図面 DXF 実座標モデル: 床 3.84 + リブ台 3 (193.2×173.2)、M4 インサート ×4、タッピングボス ×10、カバービス柱。ボス高さ 10 は仮値 (要実測)。3D STEP は会員 DL 待ち
if (show_vessel) color("LightSteelBlue", 0.22) translate([0, 0, 0])  import("../../parts/parent/exterior/cots/bcas212310g/bcas212310g.stl");
// Non-printable conservative lid exclusion volume; underside datum90.64 from existing box drawing model. Not detailed vendor lid CAD.
if (show_interior) color("LightGray", 0.18)  import("../../parts/parent/interior/printed/parent_hand_service/lid_keepout.stl");
