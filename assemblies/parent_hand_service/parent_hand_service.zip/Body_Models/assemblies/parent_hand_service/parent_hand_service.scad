// Parametric service pose. Vendor/PCB geometry is imported without resizing.
/* [Service] */
lift_mm=0; // [0:1:61]
show_case=true;
show_service_props=true;
show_hand_space=false;
hand_port=4; // [0:MAIN USB,1:MAIN SD,2:Sony MAIN USB,3:Sony EXT USB,4:Sony SD]
assert(lift_mm>=0 && lift_mm<=61,"Travel exceeds captive stop");
color("Orange",0.9)  import("../../parts/parent/interior/printed/parent_hand_service/floor_plate.stl"); // plate
translate([0,0,lift_mm]) color("SteelBlue",1.0) translate([18, 168, 64]) import("../../parts/parent/interior/pcb/parent_main/parent_main.stl"); // p_main
color("MediumSeaGreen",1.0) translate([30, 118, 28.3]) rotate([0, 0, 90]) import("../../parts/parent/interior/pcb/parent_pwr/parent_pwr.stl"); // p_pwr
color("Gold",1.0) translate([148, 144.5, 24.8]) rotate([0, 0, 90]) import("../../parts/parent/interior/pcb/tx_improved/tx_improved.stl"); // tx_improved
translate([0,0,lift_mm]) color("SandyBrown",1.0) translate([149, 70, 63]) import("../../parts/parent/interior/cots/spresense_service_stack/spresense_service_stack.stl"); // spresense
color("DarkOrange",0.9) translate([20, 64, 20]) import("../../parts/parent/interior/printed/parent_hand_service/battery_base.stl"); // lipo_tray
color("IndianRed",1.0) translate([122.5, 108.5, 23]) rotate([0, 0, 180]) import("../../parts/common/interior/cots/lipo_3s_2200_zeee/lipo_3s_2200_zeee_pack.stl"); // lipo
color("Silver",1.0) translate([120, 0, 65]) rotate([-90, 0, 0]) import("../../parts/common/exterior/cots/wetlink_penetrator_m10/wetlink_penetrator_m10_ref_bcas.stl"); // pen_tether
color("Silver",1.0) translate([85, 0, 65]) rotate([-90, 0, 0]) import("../../parts/common/exterior/cots/wetlink_penetrator_m10/wetlink_penetrator_m10_ref_bcas.stl"); // pen_td04a
if(show_case) color("LightSteelBlue",0.22) translate([0, 0, 0]) import("../../parts/parent/exterior/cots/bcas212310g/bcas212310g.stl"); // box_bcas212310g
color("Orange",1) translate([20, 64, 49]) import("../../parts/parent/interior/printed/parent_lipo_retainer/parent_lipo_retainer_lid.stl"); // lipo_ret_lid
color("LightPink",1) translate([20, 64, 20]) import("../../parts/parent/interior/printed/parent_lipo_retainer/parent_lipo_retainer_pads.stl"); // lipo_ret_pads
color("Silver",1) translate([32, 69, 52]) import("../../parts/common/interior/cots/screw/screw_m3x12.stl"); // lipo_ret_bolt_0
color("Silver",1) translate([32, 69, 41.6]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // lipo_ret_nut_0
color("Silver",1) translate([111, 69, 52]) import("../../parts/common/interior/cots/screw/screw_m3x12.stl"); // lipo_ret_bolt_1
color("Silver",1) translate([111, 69, 41.6]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // lipo_ret_nut_1
color("Silver",1) translate([32, 114, 52]) import("../../parts/common/interior/cots/screw/screw_m3x12.stl"); // lipo_ret_bolt_2
color("Silver",1) translate([32, 114, 41.6]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // lipo_ret_nut_2
color("Silver",1) translate([111, 114, 52]) import("../../parts/common/interior/cots/screw/screw_m3x12.stl"); // lipo_ret_bolt_3
color("Silver",1) translate([111, 114, 41.6]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // lipo_ret_nut_3
color("Silver",1) translate([20, 64, 23]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // lipo_ret_mount_0
color("Silver",1) translate([123, 64, 23]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // lipo_ret_mount_1
color("Silver",1) translate([20, 119.5, 23]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // lipo_ret_mount_2
color("Silver",1) translate([123, 119.5, 23]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // lipo_ret_mount_3
translate([0,0,lift_mm]) color("Orange",1)  import("../../parts/parent/interior/printed/parent_hand_service/lift_carrier.stl"); // lift_carrier
color("Gray",1)  import("../../parts/parent/interior/printed/parent_hand_service/guide_0.stl"); // guide_0
color("Gray",1)  import("../../parts/parent/interior/printed/parent_hand_service/guide_1.stl"); // guide_1
color("Gray",1)  import("../../parts/parent/interior/printed/parent_hand_service/guide_2.stl"); // guide_2
color("Gray",1)  import("../../parts/parent/interior/printed/parent_hand_service/guide_3.stl"); // guide_3
if(lift_mm==0) color("LightGray",0.18)  import("../../parts/parent/interior/printed/parent_hand_service/lid_keepout.stl"); // lid_keepout
color("Silver",1) translate([11.5, 130, 21.8]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // guide_mount_0_0
color("Silver",1) translate([11.5, 150, 21.8]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // guide_mount_0_1
color("Silver",1) translate([11.5, 180, 21.8]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // guide_mount_1_0
color("Silver",1) translate([11.5, 200, 21.8]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // guide_mount_1_1
color("Silver",1) translate([137, 130, 21.8]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // guide_mount_2_0
color("Silver",1) translate([137, 150, 21.8]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // guide_mount_2_1
color("Silver",1) translate([137, 180, 21.8]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // guide_mount_3_0
color("Silver",1) translate([137, 200, 21.8]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // guide_mount_3_1
translate([0,0,lift_mm]) color("Silver",1) translate([22.5, 163.5, 65.6]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // main_mount_0
translate([0,0,lift_mm]) color("Silver",1) translate([22.5, 88, 65.6]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // main_mount_1
translate([0,0,lift_mm]) color("Silver",1) translate([125.5, 88, 65.6]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // main_mount_2
translate([0,0,lift_mm]) color("Silver",1) translate([125.5, 163.5, 65.6]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // main_mount_3
translate([0,0,lift_mm]) color("Silver",1) translate([151.54, 124.61, 64.6]) import("../../parts/common/interior/cots/screw/screw_m2_5x6.stl"); // sony_mount_0
translate([0,0,lift_mm]) color("Silver",1) translate([199.8, 123.34, 64.6]) import("../../parts/common/interior/cots/screw/screw_m2_5x6.stl"); // sony_mount_1
translate([0,0,lift_mm]) color("Silver",1) translate([156.62, 72.54, 64.6]) import("../../parts/common/interior/cots/screw/screw_m2_5x6.stl"); // sony_mount_2
translate([0,0,lift_mm]) color("Silver",1) translate([184.56, 72.54, 64.6]) import("../../parts/common/interior/cots/screw/screw_m2_5x6.stl"); // sony_mount_3
color("Silver",1) translate([35, 123, 29.9]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // pwr_mount_0
color("Silver",1) translate([109, 213, 29.9]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // pwr_mount_1
color("Silver",1) translate([35, 213, 29.9]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // pwr_mount_2
color("Silver",1) translate([109, 123, 29.9]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // pwr_mount_3
color("Silver",1) translate([194, 210.5, 26.4]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // tx_mount_0
color("Silver",1) translate([194, 144.5, 26.4]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // tx_mount_1
color("Silver",1) translate([152, 210.5, 26.4]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // tx_mount_2
color("Silver",1) translate([152, 144.5, 26.4]) import("../../parts/common/interior/cots/screw/screw_m3x8.stl"); // tx_mount_3
translate([0,0,lift_mm]) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/stop_pin_0.stl"); // stop_pin_0
translate([0,0,lift_mm]) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/stop_pin_1.stl"); // stop_pin_1
translate([0,0,lift_mm]) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/stop_pin_2.stl"); // stop_pin_2
translate([0,0,lift_mm]) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/stop_pin_3.stl"); // stop_pin_3
if(lift_mm==0) color("Yellow",1) translate([-0.8, -52, 34.3]) rotate([0, 90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/service_prop_0.stl"); // stored_prop_0
color("Silver",1) translate([11.5, 79, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_0_0
color("Silver",1) translate([11.5, 79, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_0_0
if(lift_mm==0) color("Silver",1) translate([-0.8, -52, 34.3]) rotate([0, 90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_0_0.stl"); // stored_tie_rod_0_0
if(lift_mm==0) color("Silver",1) translate([-0.8, -52, 34.3]) rotate([0, 90, 0]) translate([11.5, 79, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_0_0
color("Silver",1) translate([11.5, 97, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_0_1
color("Silver",1) translate([11.5, 97, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_0_1
if(lift_mm==0) color("Silver",1) translate([-0.8, -52, 34.3]) rotate([0, 90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_0_1.stl"); // stored_tie_rod_0_1
if(lift_mm==0) color("Silver",1) translate([-0.8, -52, 34.3]) rotate([0, 90, 0]) translate([11.5, 97, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_0_1
if(lift_mm==0) color("Yellow",1) translate([-0.8, -52, 162.8]) rotate([0, 90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/service_prop_1.stl"); // stored_prop_1
color("Silver",1) translate([132, 79, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_1_0
color("Silver",1) translate([132, 79, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_1_0
if(lift_mm==0) color("Silver",1) translate([-0.8, -52, 162.8]) rotate([0, 90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_1_0.stl"); // stored_tie_rod_1_0
if(lift_mm==0) color("Silver",1) translate([-0.8, -52, 162.8]) rotate([0, 90, 0]) translate([132, 79, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_1_0
color("Silver",1) translate([132, 97, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_1_1
color("Silver",1) translate([132, 97, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_1_1
if(lift_mm==0) color("Silver",1) translate([-0.8, -52, 162.8]) rotate([0, 90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_1_1.stl"); // stored_tie_rod_1_1
if(lift_mm==0) color("Silver",1) translate([-0.8, -52, 162.8]) rotate([0, 90, 0]) translate([132, 97, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_1_1
if(lift_mm==0) color("Yellow",1) translate([133.5, -151, 17.8]) rotate([0, -90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/service_prop_2.stl"); // stored_prop_2
color("Silver",1) translate([21, 178, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_2_0
color("Silver",1) translate([21, 178, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_2_0
if(lift_mm==0) color("Silver",1) translate([133.5, -151, 17.8]) rotate([0, -90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_2_0.stl"); // stored_tie_rod_2_0
if(lift_mm==0) color("Silver",1) translate([133.5, -151, 17.8]) rotate([0, -90, 0]) translate([21, 178, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_2_0
color("Silver",1) translate([21, 196, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_2_1
color("Silver",1) translate([21, 196, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_2_1
if(lift_mm==0) color("Silver",1) translate([133.5, -151, 17.8]) rotate([0, -90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_2_1.stl"); // stored_tie_rod_2_1
if(lift_mm==0) color("Silver",1) translate([133.5, -151, 17.8]) rotate([0, -90, 0]) translate([21, 196, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_2_1
if(lift_mm==0) color("Yellow",1) translate([133.5, -154, -80.7]) rotate([0, -90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/service_prop_3.stl"); // stored_prop_3
color("Silver",1) translate([127.5, 181, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_3_0
color("Silver",1) translate([127.5, 181, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_3_0
if(lift_mm==0) color("Silver",1) translate([133.5, -154, -80.7]) rotate([0, -90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_3_0.stl"); // stored_tie_rod_3_0
if(lift_mm==0) color("Silver",1) translate([133.5, -154, -80.7]) rotate([0, -90, 0]) translate([127.5, 181, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_3_0
color("Silver",1) translate([127.5, 199, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_3_1
color("Silver",1) translate([127.5, 199, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_3_1
if(lift_mm==0) color("Silver",1) translate([133.5, -154, -80.7]) rotate([0, -90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_3_1.stl"); // stored_tie_rod_3_1
if(lift_mm==0) color("Silver",1) translate([133.5, -154, -80.7]) rotate([0, -90, 0]) translate([127.5, 199, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_3_1
if(lift_mm==0) color("Yellow",1) translate([133.5, -74, -87.2]) rotate([0, -90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/service_prop_4.stl"); // stored_prop_4
color("Silver",1) translate([142, 101, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_4_0
color("Silver",1) translate([142, 101, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_4_0
if(lift_mm==0) color("Silver",1) translate([133.5, -74, -87.2]) rotate([0, -90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_4_0.stl"); // stored_tie_rod_4_0
if(lift_mm==0) color("Silver",1) translate([133.5, -74, -87.2]) rotate([0, -90, 0]) translate([142, 101, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_4_0
color("Silver",1) translate([142, 119, 10.94]) import("../../parts/common/interior/cots/screw/screw_nut_m3.stl"); // fixed_prop_floor_nut_4_1
color("Silver",1) translate([142, 119, 13.34]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // fixed_prop_floor_washer_4_1
if(lift_mm==0) color("Silver",1) translate([133.5, -74, -87.2]) rotate([0, -90, 0]) import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_4_1.stl"); // stored_tie_rod_4_1
if(lift_mm==0) color("Silver",1) translate([133.5, -74, -87.2]) rotate([0, -90, 0]) translate([142, 119, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // stored_prop_top_washer_4_1
if(lift_mm==0) color("Black",1)  import("../../parts/parent/interior/printed/parent_hand_service/storage_strap_0.stl"); // stored_strap_0
if(lift_mm==0) color("Black",1)  import("../../parts/parent/interior/printed/parent_hand_service/storage_strap_1.stl"); // stored_strap_1
if(show_service_props && lift_mm==61) color("Yellow",1)  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_0.stl"); // service_prop_0
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_0_0.stl"); // tie_rod_0_0
if(show_service_props && lift_mm==61) color("Silver",1) translate([11.5, 79, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_0_0
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_0_1.stl"); // tie_rod_0_1
if(show_service_props && lift_mm==61) color("Silver",1) translate([11.5, 97, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_0_1
if(show_service_props && lift_mm==61) color("Yellow",1)  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_1.stl"); // service_prop_1
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_1_0.stl"); // tie_rod_1_0
if(show_service_props && lift_mm==61) color("Silver",1) translate([132, 79, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_1_0
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_1_1.stl"); // tie_rod_1_1
if(show_service_props && lift_mm==61) color("Silver",1) translate([132, 97, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_1_1
if(show_service_props && lift_mm==61) color("Yellow",1)  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_2.stl"); // service_prop_2
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_2_0.stl"); // tie_rod_2_0
if(show_service_props && lift_mm==61) color("Silver",1) translate([21, 178, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_2_0
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_2_1.stl"); // tie_rod_2_1
if(show_service_props && lift_mm==61) color("Silver",1) translate([21, 196, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_2_1
if(show_service_props && lift_mm==61) color("Yellow",1)  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_3.stl"); // service_prop_3
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_3_0.stl"); // tie_rod_3_0
if(show_service_props && lift_mm==61) color("Silver",1) translate([127.5, 181, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_3_0
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_3_1.stl"); // tie_rod_3_1
if(show_service_props && lift_mm==61) color("Silver",1) translate([127.5, 199, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_3_1
if(show_service_props && lift_mm==61) color("Yellow",1)  import("../../parts/parent/interior/printed/parent_hand_service/service_prop_4.stl"); // service_prop_4
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_4_0.stl"); // tie_rod_4_0
if(show_service_props && lift_mm==61) color("Silver",1) translate([142, 101, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_4_0
if(show_service_props && lift_mm==61) color("Silver",1)  import("../../parts/parent/interior/printed/parent_hand_service/tie_rod_4_1.stl"); // tie_rod_4_1
if(show_service_props && lift_mm==61) color("Silver",1) translate([142, 119, 119.8]) import("../../parts/common/interior/cots/screw/screw_washer_m3_05.stl"); // prop_top_washer_4_1
if(show_hand_space && hand_port==0) color([0,0.8,0.55,0.25]) translate([-5.890000000000001,-6.269999999999996,51.099999999999994+lift_mm]) cube([90,75,35]);
if(show_hand_space && hand_port==1) color([0,0.8,0.55,0.25]) translate([17,-4.709999999999994,49.0+lift_mm]) cube([90,75,35]);
if(show_hand_space && hand_port==2) color([0,0.8,0.55,0.25]) translate([124.28999999999999,-18.599999999999994,48.599999999999994+lift_mm]) cube([90,75,35]);
if(show_hand_space && hand_port==3) color([0,0.8,0.55,0.25]) translate([148.6,-16.060000000000002,44.0+lift_mm]) cube([90,75,35]);
if(show_hand_space && hand_port==4) color([0,0.8,0.55,0.25]) translate([141.18,155.28,47.900000000000006+lift_mm]) cube([90,75,35]);
