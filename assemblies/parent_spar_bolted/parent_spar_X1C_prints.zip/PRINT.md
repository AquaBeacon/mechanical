# X1 Carbon 印刷用セット

16種類・23点。STLは印刷向きに調整済み。1部品ずつスライス検証。

Generic PETG / Textured PEI Plate / 0.4 mm nozzle / 0.20 mm / 壁6周 / 上下6層 / Gyroid 40% / 外側ブリム5 mm / 自動通常サポート。Bambu Studio X1 Carbon設定の禁止領域を維持。XY中心(138,128)へ置く。

スライサー見積合計（数量分、ブリム・サポート込み）：約5.20 kg、約150.6時間。実機時間・完成品重量ではない。

|ファイル|数量|外形 mm|
|---|---:|---|
|dji_osmo_action6_mount.stl|1|104 × 79.45 × 84.5|
|parent_deck.stl|1|216 × 236 × 60|
|parent_spar_ballast_body.stl|1|120 × 120 × 51|
|parent_spar_ballast_lid.stl|1|120 × 120 × 6|
|parent_spar_beam_lower.stl|1|180 × 32 × 32|
|parent_spar_beam_upper.stl|1|107 × 32 × 32|
|parent_spar_camera_bridge.stl|1|140 × 78 × 180|
|parent_spar_coupler_half.stl|2|54 × 64 × 26.75|
|parent_spar_disk.stl|1|225 × 225 × 5|
|parent_spar_fin.stl|4|65 × 125 × 4|
|parent_spar_float_body.stl|2|225 × 225 × 180|
|parent_spar_float_bottom.stl|1|225 × 225 × 48|
|parent_spar_float_lid.stl|2|225 × 225 × 6|
|parent_spar_float_top.stl|1|225 × 225 × 28|
|parent_spar_gps_bridge.stl|1|183 × 96 × 100|
|parent_spar_hub.stl|2|88 × 88 × 32|

組立STEP・固定方法・シール・未検証条件は assemblies/parent_spar_bolted/README.md を参照。浮体は実機で水密試験と浮力・傾斜試験を行う。箱・機器・金属錘・金具・シールは購入品。
