from pathlib import Path
import json,os,runpy
R=Path(__file__).resolve().parents[1];O=R/'assemblies/parent_hand_service'
a=json.loads((O/'placement.json').read_text(encoding='utf-8'));f=runpy.run_path(str(R/'scad/lib/asm_gen.py'));ops=f['ops_to_scad']
s='''// Parametric service pose. Vendor/PCB geometry is imported without resizing.
/* [Service] */
lift_mm=0; // [0:1:61]
show_case=true;
show_service_props=true;
show_hand_space=false;
hand_port=4; // [0:MAIN USB,1:MAIN SD,2:Sony MAIN USB,3:Sony EXT USB,4:Sony SD]
assert(lift_mm>=0 && lift_mm<=61,"Travel exceeds captive stop");
'''
for it in a['items']+a['service_only']:
 p=R/it['part']/(it.get('file',Path(it['part']).name)+'.stl');rel=os.path.relpath(p,O).replace('\\','/')
 prefix=''
 if it['label']=='box_bcas212310g':prefix='if(show_case) '
 if it['label']=='lid_keepout' or it['label'].startswith('stored_'):prefix='if(lift_mm==0) '
 if it in a['service_only']:prefix='if(show_service_props && lift_mm==61) '
 if it['label'] in a['moving_labels']:prefix+='translate([0,0,lift_mm]) '
 s+=prefix+f'color("{it.get("color","Gray")}",{it.get("alpha",1)}) '+ops(it['ops'])+f' import("{rel}"); // {it["label"]}\n'
ports=json.loads((O/'verification.json').read_text(encoding='utf-8'))['ports']
for i,p in enumerate(ports):
 x,y,z=p['mouth_mm'];d=1 if p['port']=='SONY_SD' else -1
 s+=f'if(show_hand_space && hand_port=={i}) color([0,0.8,0.55,0.25]) translate([{x-45},{y+12 if d==1 else y-87},{z-61-17.5}+lift_mm]) cube([90,75,35]);\n'
(O/'parent_hand_service.scad').write_text(s,encoding='utf-8')
print('Generated parametric service pose and optional hand proxy')
