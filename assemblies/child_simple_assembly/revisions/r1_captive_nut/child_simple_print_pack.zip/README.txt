Simple child enclosure PROTOTYPE. 3 parts, M3 mounts 40x40 mm.
STLs are oriented for printing. Enable supports, PETG, 100% infill.
Sources are standalone: open sources/child_simple_front.scad etc.
Structural FEA has NOT passed mesh convergence or all worst-element strength criteria.
See verification.md; confirm dimensions and loads before operational use.
