// =====================================================================
// bcas212310g.scad — タカチ BCAS212310G 防水ボックス モデル (購入品)
// 配置検討・アセンブリ表示用。印刷対象ではない。
//
// 寸法の出典: タカチ公開図面 ref/BCAS212310G.dxf (2026/02/24 版, 1:1) を
//   解析して取った実座標 (円中心・半径・寸法値)。3D STEP はタカチ会員ログインが
//   必要で未取得 (ref/ に置いたら bcas212310g.md の手順で差し替える)。
//
// 座標系: 図面の 230 辺を機体 Y、210 辺を機体 X に取る (子機と揃えて +Y 前)。
//   原点 = 外形左下、箱底外面 z=0。
//   図面の内視図 (230 横 × 210 縦, 中心基準) → 本モデル (X, Y) = (図面 y, 図面 x)。
//
// 図面から確定した値:
//   外形 230 × 210 × 100.3 (カバー 20 含む)、側壁 3.1、床 3.84
//   床上リブ台 +3 (193.2 × 173.2 の中央台 = 「底リブ部」有効内寸)
//   プレート面レベル有効内寸 217.8 × 197.8
//   コーナー M4 インサート ×4: 図面 (±90, ±80) → 本モデル (±80 X, ±90 Y)、ボス Ø10
//   M4 タッピングボス ×10 (Ø8, 下穴 Ø3.4):
//     図面 (±40, ±80) ×4 → 本モデル X=±80, Y=±40
//     図面 (±90, 0/±40) ×6 → 本モデル X=0/±40, Y=±90
//   カバービス ボス ×4: 図面 (±106, ±96) → 本モデル (±96 X, ±106 Y)、Ø10.5
// 仮値 (図面の断面から読み取れず、実測待ち): boss_h (インサート/ボス高さ)
// =====================================================================

/* [外形 (図面)] */
ow = 210;      // X (図面の 210 辺)
od = 230;      // Y (図面の 230 辺)
oh = 100.3;    // H (カバー含む)
wall = 3.1;    // 側壁
floor_t = 3.84;// 床 (図面 3.84。旧モデルは 3.8。z スタックは 3.8 基準のまま = 誤差 0.04)

/* [内寸 (図面)] */
iw  = 197.8;   // X プレート面レベル
idp = 217.8;   // Y プレート面レベル
rib_w = 173.2; // 床上リブ台 X
rib_d = 193.2; // 床上リブ台 Y
rib_h = 3;     // リブ台の高さ (床上)
ih  = 86.8;    // 床からカバー内面まで (図面 Max dim. 86.8)

/* [ボス] */
boss_h   = 10;      // 仮値 (要実測): インサート/タッピングボスの床からの高さ
ins_d    = 10;      // コーナー M4 インサートボス径 (図面 r5)
ins_pitch= [160, 180];   // 本モデル X × Y (図面 160 縦 × 180 横)
tap_d    = 8;       // タッピングボス径 (図面 r4)
tap_pilot= 3.4;     // 図面 "12-M4用ボス" 寸法 3.4
tap_pos  = concat(
    [for (sx = [-1, 1], sy = [-1, 1]) [sx*80, sy*40]],         // 図面 (±40, ±80)
    [for (sx = [-1, 0, 1], sy = [-1, 1]) [sx*40, sy*90]]);     // 図面 (±90, 0/±40)
cov_d    = 10.5;    // カバービス ボス径 (図面 r5.25)
cov_pos  = [for (sx = [-1, 1], sy = [-1, 1]) [sx*96, sy*106]];  // 図面 (±106, ±96)

/* [追加工 (自作): 南壁 ペネトレータ穴] — 図面には無い。こちらで開ける穴 */
// WetLink Penetrator M10 (parts/common/exterior/cots/wetlink_penetrator_m10) を
// 南壁 (Y=0) の上部に 2 本。C1 テザー と C3 TD04A。
// 高さ z=65 は「P-MAIN 天面 45 + サービスループ」から (docs/親機内装_収まり検討.md §7)。
pen_d    = 10.2;         // バカ穴 (WetLink M10 は 10.0-10.2)
pen_z    = 65;           // 軸高さ (箱底外面 z=0 基準)
pen_x    = [85, 120];    // 南壁の X (昇順): 120 = テザー (P-MAIN J_TETH1 箱 x123 の直下) / 85 = TD04A
                         // SPRESENSE (箱 X 134.5-188、天面が仮値) の**上を通さない**ために東端は 121.65 まで。
                         // 内装側の検証は spec/parent_interior_layout.py check_penetrators()
pen_seat = 18.5;         // 六角頭の外接径 = 平坦な座面として要る Ø (**要確認**: 側壁のテーパ)
pen_in   = 19.7;         // 内側ナットの外接径 (干渉検討用)
cover_h  = 20;           // 外形 100.3 に含まれるカバーの高さ (図面) → 本体上端 = oh - cover_h
model_wall_y = (od - idp)/2;   // 6.1 = このモデルの Y 側壁厚 (実壁 3.08 + テーパ/段差)
                               // → ペネトレータのナットもこの面に載せる (wetlink..._ref の bcas バリアント)

$fn = 48;

cx = ow/2; cy = od/2;

// ---- 図面との整合チェック --------------------------------------------
assert(abs((ow - 2*wall) - 203.8) < 0.1 && abs((od - 2*wall) - 223.8) < 0.1, "壁厚と外形が図面と合わない");
assert(rib_w < iw && rib_d < idp, "リブ台が内寸より大きい");
for (p = tap_pos) assert(abs(p[0]) <= rib_w/2 - tap_d/2 + 8 && abs(p[1]) <= rib_d/2 + 2, str("タッピングボスがリブ台の外: ", p));
for (p = cov_pos) assert(abs(p[0]) + cov_d/2 <= ow/2 && abs(p[1]) + cov_d/2 <= od/2, "カバービスボスが外形の外");

// 南壁ペネトレータ穴: 座面が壁からはみ出さない / 床・蓋・カバービス柱と干渉しない /
// 2 本の間にトルクレンチ (16mm 六角, 3.5 N·m) が入る
assert(pen_z - pen_seat/2 > floor_t + rib_h + 2, "ペネトレータ穴が床リブ台に近すぎる");
// 内側: ナットが内腔に収まる / 外側: 六角頭が**本体上端 (カバーが被る線)** より下
assert(pen_z + pen_in/2 < floor_t + ih - 2, "内側ナットが蓋内面に近すぎる");
assert(pen_z + pen_seat/2 < oh - cover_h - 3,
       "六角頭が本体上端 (カバー) に近すぎる = 外側から工具が入らない");
for (x = pen_x) {
    assert(x - pen_seat/2 > wall + 2 && x + pen_seat/2 < ow - wall - 2,
           str("ペネトレータ座が南壁に収まらない: x=", x));
    for (p = cov_pos) if (cy + p[1] < od/2)   // 南側のカバービス柱だけ見る
        assert(abs(x - (cx + p[0])) > (pen_in + cov_d)/2 + 3,
               str("ペネトレータ (内側ナット) がカバービス柱に当たる: x=", x));
}
for (i = [0 : len(pen_x) - 2])
    assert(pen_x[i+1] - pen_x[i] >= 30,
           "ペネトレータ 2 本のピッチが 30 未満 = トルクレンチが振れない");

echo(str("bcas212310g: insert bosses at ", [for (sx=[-1,1], sy=[-1,1]) [cx+sx*ins_pitch[0]/2, cy+sy*ins_pitch[1]/2]],
         "  tapping bosses (box coords) = ", [for (p = tap_pos) [cx+p[0], cy+p[1]]]));
echo(str("bcas212310g: PENETRATORS (south wall y=0) d=", pen_d, " z=", pen_z, " x=", pen_x, " model wall_y=", model_wall_y));

difference() {
    cube([ow, od, oh]);
    // 内腔 (床上はプレート面レベルの内寸で一定とする。テーパ・カバー段差は省略)
    translate([(ow - iw)/2, (od - idp)/2, floor_t]) cube([iw, idp, oh]);
    // 追加工: 南壁 (Y=0) のペネトレータ穴 ×2
    // 穴はモデルの側壁 (外形 - 有効内寸 = 6.1。実壁 3.08 + テーパ/段差ぶん) を貫通させる
    for (x = pen_x) translate([x, -1, pen_z]) rotate([-90, 0, 0]) cylinder(d = pen_d, h = model_wall_y + 2);
}
// 床上リブ台 (図面「底リブ部」有効寸法 193.2 × 173.2)。中実で近似
translate([cx - rib_w/2, cy - rib_d/2, floor_t]) cube([rib_w, rib_d, rib_h]);
// コーナー M4 インサートボス
for (sx = [-1, 1]) for (sy = [-1, 1])
    translate([cx + sx*ins_pitch[0]/2, cy + sy*ins_pitch[1]/2, floor_t])
        difference() {
            cylinder(d = ins_d, h = boss_h);
            translate([0, 0, boss_h - 8]) cylinder(d = 3.3, h = 9);
        }
// M4 タッピングボス ×10
for (p = tap_pos)
    translate([cx + p[0], cy + p[1], floor_t])
        difference() {
            cylinder(d = tap_d, h = boss_h);
            translate([0, 0, boss_h - 8]) cylinder(d = tap_pilot, h = 9);
        }
// カバービス ボス (コーナー柱)。床から上端まで
for (p = cov_pos)
    translate([cx + p[0], cy + p[1], floor_t]) cylinder(d = cov_d, h = oh - floor_t - 20);
